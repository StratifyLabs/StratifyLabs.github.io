
var data = "{ \"data\": [{ \"text\": \"List Item 1\" },
        { \"text\": \"List Item 2\" },
        { \"text\": \"List Item 3\" },
        { \"text\": \"List Item 4\" } ]
}";

