CTEST_CUSTOM_COVERAGE_EXCLUDE
-----------------------------

A list of regular expressions which will be used to exclude files by their
path from coverage output by the :command:`ctest_coverage` command.

.. include:: CTEST_CUSTOM_XXX.txt
