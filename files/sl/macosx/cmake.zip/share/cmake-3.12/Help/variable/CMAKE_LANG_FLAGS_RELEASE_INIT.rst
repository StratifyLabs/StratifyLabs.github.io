CMAKE_<LANG>_FLAGS_RELEASE_INIT
-------------------------------

This variable is the ``Release`` variant of the
:variable:`CMAKE_<LANG>_FLAGS_<CONFIG>_INIT` variable.
