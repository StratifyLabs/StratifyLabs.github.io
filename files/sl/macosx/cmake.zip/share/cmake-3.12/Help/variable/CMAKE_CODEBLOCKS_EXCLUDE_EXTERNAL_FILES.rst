CMAKE_CODEBLOCKS_EXCLUDE_EXTERNAL_FILES
---------------------------------------

Change the way the CodeBlocks generator creates project files.

If this variable evaluates to ``ON`` the generator excludes from
the project file any files that are located outside the project root.
