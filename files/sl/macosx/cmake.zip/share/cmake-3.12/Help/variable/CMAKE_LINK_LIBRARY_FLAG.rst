CMAKE_LINK_LIBRARY_FLAG
-----------------------

Flag to be used to link a library into an executable.

The flag will be used to specify a library to link to an executable.
On most compilers this is ``-l``.
