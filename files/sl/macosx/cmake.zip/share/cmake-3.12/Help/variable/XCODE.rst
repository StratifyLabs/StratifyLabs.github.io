XCODE
-----

``True`` when using :generator:`Xcode` generator.
