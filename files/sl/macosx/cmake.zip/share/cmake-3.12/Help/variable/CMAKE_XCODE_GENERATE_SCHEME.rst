CMAKE_XCODE_GENERATE_SCHEME
---------------------------

If enabled, the Xcode generator will generate schema files. Those are
are useful to invoke analyze, archive, build-for-testing and test
actions from the command line.

.. note::

  The Xcode Schema Generator is still experimental and subject to
  change.
