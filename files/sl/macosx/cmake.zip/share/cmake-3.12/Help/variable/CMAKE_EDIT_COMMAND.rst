CMAKE_EDIT_COMMAND
------------------

Full path to :manual:`cmake-gui(1)` or :manual:`ccmake(1)`.  Defined only for
:ref:`Makefile Generators` when not using an "extra" generator for an IDE.

This is the full path to the CMake executable that can graphically
edit the cache.  For example, :manual:`cmake-gui(1)` or :manual:`ccmake(1)`.
