CMAKE_Swift_LANGUAGE_VERSION
----------------------------

Set to the Swift language version number.  If not set, the legacy "2.3"
version is assumed.
