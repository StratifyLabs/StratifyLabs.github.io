CMAKE_VS_SDK_REFERENCE_DIRECTORIES
----------------------------------

This variable allows to override Visual Studio default Reference Directories.
