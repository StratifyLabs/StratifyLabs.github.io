CMAKE_VS_SDK_INCLUDE_DIRECTORIES
--------------------------------

This variable allows to override Visual Studio default Include Directories.
