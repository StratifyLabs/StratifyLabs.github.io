CMAKE_ANDROID_PROGUARD
----------------------

Default value for the :prop_tgt:`ANDROID_PROGUARD` target property.
See that target property for additional information.
