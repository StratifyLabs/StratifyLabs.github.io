CTEST_DROP_SITE_CDASH
---------------------

Specify the CTest ``IsCDash`` setting
in a :manual:`ctest(1)` dashboard client script.
