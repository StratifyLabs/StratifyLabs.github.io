CTEST_USE_LAUNCHERS_DEFAULT
---------------------------

Initializes the :variable:`CTEST_USE_LAUNCHERS` variable if not already defined.
